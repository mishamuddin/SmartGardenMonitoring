﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace Smart_Garden_Monitoring
{
    public partial class Form1 : Form
    {
        string akuisisifilepath; string akuisisifilename;
        public System.IO.Ports.SerialPort ser_port;
        public Form1()
        {
            InitializeComponent();
            foreach (String s in System.IO.Ports.SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(s);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            akuisisifilepath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            akuisisifilename = "Smart Garden" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".sgf";
            ser_port = new System.IO.Ports.SerialPort(comboBox1.Text, 9600,
            System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            try
            {
                ser_port.Open();
                btnDisconnect.Enabled = true;
                btnConnect.Enabled = false;
                richTextBox1.AppendText("Connected\n");
                ser_port.DataReceived += new SerialDataReceivedEventHandler(ser_port_DataReceived);
            }
            catch (Exception ex) 
            { 
                MessageBox.Show(ex.ToString(), "Error"); 
            }
        }
        String txt; 
        SignalDataReceivedAll LocY; 
        String txtY;
        delegate void SetTextCallback(String text);
        private void ser_port_DataReceived(Object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            txtY = ser_port.ReadLine().ToString();
            txt += "Received: " + txtY + "\r\n";
            SetText(txt.ToString());
            this.Invoke(new EventHandler(ShowData));    
        }

        string sen1;
        string sen2;
        string sen3;
        private void ShowData(object sender, EventArgs e)
        {
            // richTextBox1.Text += txtY;//liat data masuk di textbox
            char[] delimiterChars = { ';' };
            String[] separete_data = txtY.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);
            int jumlah_data = separete_data.Length;
            if (jumlah_data == 3)
            {
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(akuisisifilepath, akuisisifilename), true))
                {
                    outputFile.Write(txtY+"\r\n");
                }

                sen1 = separete_data[0];
                sen2 = separete_data[1];
                sen3 = separete_data[2];
                

                LocY.Sensor1 = Int32.Parse(sen1);
                LocY.Sensor2 = Int32.Parse(sen2);
                LocY.Sensor3 = Int32.Parse(sen3);
                SetLocXY(LocY);


                richTextBox1.Text += "Received = " + LocY.Sensor1 + " " + LocY.Sensor2 + " " + LocY.Sensor3  + "\r\n";

                textBox1.Text = sen1 + "\r\n";

                //menampilkan data sensor 2
                textBox2.Text = sen2 + "\r\n";

                //menampilkan data sensor 3
                textBox3.Text = sen3 + "\r\n";         
            }


        }
        private void SetText(String text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richTextBox1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.richTextBox1.Text = text;
            }
        }
        struct SignalDataReceivedAll
        {
            public int Sensor1;
            public int Sensor2;
            public int Sensor3;
            

        };

        private void Form1_Load(object sender, EventArgs e)
        {
            btnDisconnect.Enabled = false;
            btnConnect.Enabled = true;
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (ser_port.IsOpen)
            {
                ser_port.Close();
                btnDisconnect.Enabled = false;
                btnConnect.Enabled = true;
                richTextBox1.AppendText("Disconnected\n");
                MessageBox.Show("Data Telah Disimpan Pada Folder : " + akuisisifilepath);
                
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Boolean data_sensor = timer1.Enabled;
            timer1.Enabled = !data_sensor;
        }

        delegate void SetLocXYCallback(SignalDataReceivedAll Z);
        int LocX;
        private void SetLocXY(SignalDataReceivedAll Z)
        {
            if (this.chart1.InvokeRequired)
            {
                SetLocXYCallback XY = new SetLocXYCallback(SetLocXY);
                this.Invoke(XY, new object[] { Z });
            }
            else
            {
                LocX++;
                chart1.Series["Temperature"].Points.AddXY(LocX, Z.Sensor1);
                chart1.Series["Temperature"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                chart1.Series["Temperature"].Color = Color.Blue;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Size = 100;
                if(LocX > 100)
                {
                    chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Position = chart1.ChartAreas["ChartArea1"].AxisX.Maximum - 100;
                }
                else
                {
                    chart1.ChartAreas[0].AxisX.ScaleView.Position = 0;
                }
            }
        }


        string sFileName;
        string line;
        private async void btnOpen_Click(object sender, EventArgs e)
        {
            using(OpenFileDialog ofd =  new OpenFileDialog() { Filter = "Smart Garden File|*.sgf", ValidateNames = true, Multiselect = false })
            {
                if(ofd.ShowDialog() == DialogResult.OK)
                {
                    sFileName = ofd.FileName;
                    StreamReader sr = new StreamReader(sFileName);
                    while((line = sr.ReadLine()) != null)
                    {
                        
                        richTextBox1.AppendText(line);
                        richTextBox1.AppendText(Environment.NewLine);

                        char[] delimiterChars = { ';' };
                        string[] separete_data = line.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);

                        string sen1 = separete_data[0];
                        string sen2 = separete_data[1];
                        string sen3 = separete_data[2];

                        LocY.Sensor1 = Int32.Parse(sen1);
                        LocY.Sensor2 = Int32.Parse(sen2);
                        LocY.Sensor3 = Int32.Parse(sen3);
                        SetLocXY(LocY);

                        richTextBox1.Text += "Received = " + LocY.Sensor1 + " " + LocY.Sensor2 + " " + LocY.Sensor3 + "\r\n";
                        textBox1.Text = sen1.ToString() + "\r\n";
                        textBox2.Text = sen2.ToString() + "\r\n";
                        textBox3.Text = sen3.ToString() + "\r\n";                        
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
